package Assignment3;
//Xiaoquan Huang
//CS313
public class Project3 {
	
	public static void main(String[] args) {
		Project3Controller.createObject();
	}
}