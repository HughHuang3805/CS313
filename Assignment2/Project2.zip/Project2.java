package Assignment2;
//Xiaoquan Huang
//CS313
public class Project2 {

	public static void main(String[] args) {
		//uses file chooser to choose the input file
		Project2Controller.createObject();
	}
}
